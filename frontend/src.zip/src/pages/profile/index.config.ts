export default definePageConfig({
  navigationBarTitleText: '我的',
  navigationBarBackgroundColor: '#1677FF',
  navigationBarTextStyle: 'white',
  enablePullDownRefresh: true
})
