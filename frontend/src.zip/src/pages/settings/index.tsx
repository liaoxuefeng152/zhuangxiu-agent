import React from 'react'
import { View, Text } from '@tarojs/components'

const SettingsPage = () => {
  return (
    <View>
      <Text>Settings页面 - 建设中</Text>
    </View>
  )
}

export default SettingsPage
