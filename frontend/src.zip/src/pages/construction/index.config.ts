export default definePageConfig({
  navigationBarTitleText: '施工陪伴',
  navigationBarBackgroundColor: '#1677FF',
  navigationBarTextStyle: 'white',
  enablePullDownRefresh: true
})
