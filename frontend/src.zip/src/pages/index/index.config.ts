export default definePageConfig({
  navigationBarTitleText: '装修决策Agent',
  navigationBarBackgroundColor: '#1677FF',
  navigationBarTextStyle: 'white',
  enableShareAppMessage: true,
  onReachBottomDistance: 50
})
