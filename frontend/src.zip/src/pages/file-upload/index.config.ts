export default definePageConfig({
  navigationBarTitleText: '文件上传',
  navigationBarBackgroundColor: '#1677FF',
  navigationBarTextStyle: 'white',
  enablePullDownRefresh: false
})
