import React from 'react'
import { View, Text } from '@tarojs/components'

const FileUploadPage = () => {
  return (
    <View>
      <Text>file-upload页面 - 建设中</Text>
    </View>
  )
}

export default FileUploadPage
