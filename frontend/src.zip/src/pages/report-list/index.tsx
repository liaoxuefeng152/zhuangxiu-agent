import React from 'react'
import { View, Text } from '@tarojs/components'

const ReportListPage = () => {
  return (
    <View>
      <Text>report-list页面 - 建设中</Text>
    </View>
  )
}

export default ReportListPage
