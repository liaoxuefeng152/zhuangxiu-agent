import React from 'react'
import { View, Text } from '@tarojs/components'

const QuoteUploadPage = () => {
  return (
    <View>
      <Text>quote-upload页面 - 建设中</Text>
    </View>
  )
}

export default QuoteUploadPage
