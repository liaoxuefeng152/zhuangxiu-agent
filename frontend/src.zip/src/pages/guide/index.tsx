import React from 'react'
import { View, Text } from '@tarojs/components'

const GuidePage = () => {
  return (
    <View>
      <Text>Guide页面 - 建设中</Text>
    </View>
  )
}

export default GuidePage
