import React from 'react'
import { View, Text } from '@tarojs/components'

const PhotoPage = () => {
  return (
    <View>
      <Text>Photo页面 - 建设中</Text>
    </View>
  )
}

export default PhotoPage
