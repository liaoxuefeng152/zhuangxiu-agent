export default definePageConfig({
  navigationBarTitleText: '欢迎',
  navigationBarBackgroundColor: '#1677FF',
  navigationBarTextStyle: 'white',
  navigationStyle: 'custom',
  disableScroll: true
})
