import React from 'react'
import { View, Text } from '@tarojs/components'

const CompanyScanPage = () => {
  return (
    <View>
      <Text>company-scan页面 - 建设中</Text>
    </View>
  )
}

export default CompanyScanPage
