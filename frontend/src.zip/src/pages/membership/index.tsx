import React from 'react'
import { View, Text } from '@tarojs/components'

const MembershipPage = () => {
  return (
    <View>
      <Text>Membership页面 - 建设中</Text>
    </View>
  )
}

export default MembershipPage
