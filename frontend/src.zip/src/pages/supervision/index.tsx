import React from 'react'
import { View, Text } from '@tarojs/components'

const SupervisionPage = () => {
  return (
    <View>
      <Text>Supervision页面 - 建设中</Text>
    </View>
  )
}

export default SupervisionPage
