const config = {
  pages: [
    'pages/onboarding/index',
    'pages/index/index',
    'pages/company-scan/index',
    'pages/quote-upload/index',
    'pages/contract-upload/index',
    'pages/report-detail/index',
    'pages/construction/index',
    'pages/profile/index',
    'pages/payment/index'
  ],
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#fff',
    navigationBarTitleText: '装修决策Agent',
    navigationBarTextStyle: 'black',
    backgroundColor: '#f5f5f5'
  },
  tabBar: {
    color: '#8C8C8C',
    selectedColor: '#1677FF',
    backgroundColor: '#fff',
    borderStyle: 'black',
    list: [
      {
        pagePath: 'pages/index/index',
        text: '首页',
        iconPath: 'assets/tabbar/home.png',
        selectedIconPath: 'assets/tabbar/home-active.png'
      },
      {
        pagePath: 'pages/construction/index',
        text: '施工陪伴',
        iconPath: 'assets/tabbar/construction.png',
        selectedIconPath: 'assets/tabbar/construction-active.png'
      },
      {
        pagePath: 'pages/profile/index',
        text: '我的',
        iconPath: 'assets/tabbar/profile.png',
        selectedIconPath: 'assets/tabbar/profile-active.png'
      }
    ]
  },
  permission: {
    'scope.userLocation': {
      desc: '你的位置信息将用于获取本地装修公司信息'
    }
  },
  requiredPrivateInfos: ['getLocation'],
  usingComponents: {},
  lazyCodeLoading: 'requiredComponents'
}

export default config
